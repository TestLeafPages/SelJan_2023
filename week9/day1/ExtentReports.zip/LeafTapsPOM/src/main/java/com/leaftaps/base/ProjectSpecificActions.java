package com.leaftaps.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.leaftaps.utils.ReadExcel;

import io.github.bonigarcia.wdm.WebDriverManager;
import io.netty.handler.codec.http.multipart.FileUpload;

public class ProjectSpecificActions {

	public RemoteWebDriver driver;
	public String fileName;
	public static Properties prop2;
	public ExtentReports extent;
	public String testName, testDescription, testCategory, testAuthor;
	public static ExtentTest test, node;

	@BeforeMethod
	public void preCondition() throws IOException {
		node = test.createNode(testName);
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("src/main/resources/config.properties");
		prop.load(fis);
		String browser = prop.getProperty("Browser");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		String lang = prop.getProperty("Lang");
		System.out.println(lang);

		prop2 = new Properties();
		FileInputStream fis2 = new FileInputStream("src/main/resources/" + lang + ".properties");
		prop2.load(fis2);

	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}

	@DataProvider(name = "FetchData")
	public String[][] sendData() throws IOException {
		return ReadExcel.readDataFromExcel(fileName);
	}

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@AfterSuite
	public void stopReport() {
		extent.flush();
	}
	
	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignCategory(testCategory);
		test.assignAuthor(testAuthor);
	}
	
	public void reportStep(String status, String description) {
		if (status.equalsIgnoreCase("Pass")) {
			try {
				node.pass(description, MediaEntityBuilder.createScreenCaptureFromPath("./../images/img"+takeSnap()+".png").build());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if(status.equalsIgnoreCase("Fail")) {
			try {
				node.fail(description, MediaEntityBuilder.createScreenCaptureFromPath("./../images/img"+takeSnap()+".png").build());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public int takeSnap() {
		int random = (int) (Math.random() * 9999999);
		File src = driver.getScreenshotAs(OutputType.FILE);
		File dest = new File("./images/img"+random+".png");
		try {
			FileUtils.copyFile(src, dest);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return random;
	}
}
