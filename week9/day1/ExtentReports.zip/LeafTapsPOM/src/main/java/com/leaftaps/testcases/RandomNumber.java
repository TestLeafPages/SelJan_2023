package com.leaftaps.testcases;

public class RandomNumber {

	public static void main(String[] args) {
		int random = (int) (Math.random() * 9999999);
		System.out.println(random);
	}

}
