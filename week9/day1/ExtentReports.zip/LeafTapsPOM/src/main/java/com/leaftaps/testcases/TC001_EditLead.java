package com.leaftaps.testcases;

import org.testng.annotations.Test;

import com.leaftaps.base.ProjectSpecificActions;
import com.leaftaps.pages.LoginPage;

public class TC001_EditLead extends ProjectSpecificActions{

	@Test
	public void runEditLead() {
		
//		new LoginPage(driver).enterUserName()
//		.enterPassword()
//		.clickLogin()
//		.clickCRMSFA()
//		.clickLeads()
//		.clickFindLeads();
	}
}
