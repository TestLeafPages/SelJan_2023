package com.leaftaps.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.leaftaps.base.ProjectSpecificActions;

public class LoginPage extends ProjectSpecificActions {
	
	public LoginPage(RemoteWebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = "username") 
	List<WebElement> eleUserName;
	public LoginPage enterUserName(String uName) {
//		WebElement eleUserName = driver.findElement(By.id("username"));
		try {
			eleUserName.get(0).sendKeys(uName);
			reportStep("Pass", "Username is entered successfully");
		} catch (NoSuchElementException e) {
			reportStep("Fail", "Username is not entered. "+ e);
		}
		return this;
	}

//	@FindBy(how = How.ID, using = "password") 
	// OR Condition
	@FindAll(
			{
				@FindBy(how = How.ID, using = "password"),
				@FindBy(how = How.XPATH, using = "//input[@name='PASSWORD']")
			}
			)
	@CacheLookup
	// AND Condition
//	@FindBys(
//			{
//				@FindBy(how = How.ID, using = "password"),
//				@FindBy(how = How.XPATH, using = "//[@name='PASSWORD']")
//			}
//			)
	WebElement elePassword;
	public LoginPage enterPassword(String pwd) {
		elePassword.sendKeys(pwd);
		return this;
	}

	public HomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage(driver);
	}
}
