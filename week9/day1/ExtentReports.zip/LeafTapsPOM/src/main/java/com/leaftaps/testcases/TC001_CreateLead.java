package com.leaftaps.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.base.ProjectSpecificActions;
import com.leaftaps.pages.HomePage;
import com.leaftaps.pages.LoginPage;
import com.leaftaps.pages.MyHomePage;

public class TC001_CreateLead extends ProjectSpecificActions{

	@BeforeTest
	public void setData() {
		fileName = "CreateLead";
		testName = "Create Lead";
		testDescription = "Create Lead with mandatory details";
		testCategory = "Smoke";
		testAuthor = "Haja";
	}
	
	@Test(dataProvider = "FetchData")
	public void runCreateLead(String uName, String pwd, String cName,
			String fName, String lName) {
		
		System.out.println(driver);
		
		LoginPage lp = new LoginPage(driver);
		lp.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin();
//		.clickCRMSFA()
//		.clickLeads()
//		.clickCreateLead()
//		.enterCompanyName(cName)
//		.enterFirstName(fName)
//		.enterLastName(lName)
//		.clickCreateLead()
//		.verifyFirstName(fName);
		
//		lp.enterUserName();
//		lp.enterPassword();
//		lp.clickLogin();
//		
//		HomePage hp = new HomePage();
//		hp.clickCRMSFA();
//		
//		MyHomePage mp = new MyHomePage();
//		mp.clickLeads();
		
	}
}
