package com.leaftaps.testcases;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class LearnProperties {

	public static void main(String[] args) throws IOException {
		// Create an object for Properties
		Properties prop = new Properties();
		
		// Specify the File
		FileInputStream fis = new FileInputStream("src/main/resources/config.properties");
		
		// Load the file
		prop.load(fis);
		
		// read the data
		String userName = prop.getProperty("Username");
		System.out.println(userName);
		System.out.println(prop.getProperty("Browser"));
	}

}
