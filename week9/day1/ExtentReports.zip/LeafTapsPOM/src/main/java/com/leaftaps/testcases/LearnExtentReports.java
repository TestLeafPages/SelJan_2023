package com.leaftaps.testcases;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReports {

	public static void main(String[] args) throws IOException {

		System.out.println("Report generation started");

		// Setup the physical report path
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");

		// Create an object for ExtentReports
		ExtentReports extent = new ExtentReports();

		// Attach it to the physical report
		extent.attachReporter(reporter);

		// Create a test case
		ExtentTest test = extent.createTest("CreateLead", "Create Lead with mandatory fields");
		test.assignCategory("Smoke");
		test.assignAuthor("Haja");

		// Provide step level information
		test.pass("Enter Username", MediaEntityBuilder.createScreenCaptureFromPath("./../snaps/irctc.png").build());
		test.pass("Enter Password");
		test.pass("Click Login");
		test.pass("Login is successful");

		ExtentTest test2 = extent.createTest("EditLead", "Edit the newly created Lead");
		test2.assignCategory("Sanity");
		test2.assignAuthor("Babu");
		
		// Provide step level information
		test2.info("Enter Username");
		test2.info("Enter Password");
		test2.info("Click Login");
		test2.fail("Login is failed");

		// Flush the report
		extent.flush();
	}

}
