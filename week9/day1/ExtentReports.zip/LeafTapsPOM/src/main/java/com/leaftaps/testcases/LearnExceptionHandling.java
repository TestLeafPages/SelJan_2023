package com.leaftaps.testcases;

public class LearnExceptionHandling {

	public static void main(String[] args) {
		
		int x = 10;
		int y = 5;
		int z[] = {1, 2, 3, 4};
		try {
			System.out.println(x/y);
			System.out.println(z[3]);
		} catch (ArithmeticException e) {
			System.out.println("Got Arithmetic exception. /0");
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Index out of bound");
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("Finally block");
		}
		
//		try {
//			System.out.println(z[3]);
//		} catch (ArrayIndexOutOfBoundsException e) {
//			System.out.println(e);
//		}
		System.out.println("End of program");
	}

}
