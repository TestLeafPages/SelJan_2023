package com.leaftaps.testcases;

public class LearnThrow {
	
	public void divide(int num1, int num2) {
		if (num2 != 0) {
			System.out.println(num1/num2);
		} else {
			throw new RuntimeException("Failed");
		}
	}

	public static void main(String[] args) {
		LearnThrow lt = new LearnThrow();
		lt.divide(10, 0);
	}
	
	public void sleep() throws InterruptedException {
		Thread.sleep(1000);
	}

}
