package com.leaftaps.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import com.leaftaps.utils.ReadExcel;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ProjectSpecificActions {

	public RemoteWebDriver driver;
	public String fileName;
	public static Properties prop2;

	@BeforeMethod
	public void preCondition() throws IOException {
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream("src/main/resources/config.properties");
		prop.load(fis);
		String browser = prop.getProperty("Browser");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		String lang = prop.getProperty("Lang");
		System.out.println(lang);
		
		prop2 = new Properties();
		FileInputStream fis2 = new FileInputStream("src/main/resources/" +lang+ ".properties");
		prop2.load(fis2);
		
		
	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}

	@DataProvider(name = "FetchData", indices = 0)
	public String[][] sendData() throws IOException {
		return ReadExcel.readDataFromExcel(fileName);
	}
}
