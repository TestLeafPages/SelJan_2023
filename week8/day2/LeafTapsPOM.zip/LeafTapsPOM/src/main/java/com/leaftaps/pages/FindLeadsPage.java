package com.leaftaps.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.base.ProjectSpecificActions;

public class FindLeadsPage extends ProjectSpecificActions{

	public FindLeadsPage(RemoteWebDriver driver) {
		this.driver = driver;
	}
	
	public void enterLeadId() {
		
	}
}
